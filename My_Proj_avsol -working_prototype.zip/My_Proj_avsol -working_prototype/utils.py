import cv2
import numpy as np
import bcrypt
import pickle
from mtcnn import MTCNN
from keras_facenet import FaceNet
from database import connect_db_with_retry

# Initialize face detection and embedding models
detector = MTCNN()
embedder = FaceNet()

def detect_img(image):
    """Detect faces in an image using MTCNN."""
    detections = detector.detect_faces(image)
    return detections

def ext_face(image, box):
    """Extract face from the image using the bounding box."""
    x, y, width, height = box
    face = image[y:y+height, x:x+width]
    return face

def face_embed(face_image):
    """Generate face embedding using FaceNet."""
    # Preprocess the face image as required by FaceNet
    face_image = cv2.resize(face_image, (160, 160))
    face_image = cv2.cvtColor(face_image, cv2.COLOR_BGR2RGB)
    face_image = face_image.astype('float32')
    mean, std = face_image.mean(), face_image.std()
    face_image = (face_image - mean) / std
    face_image = np.expand_dims(face_image, axis=0)
    
    # Generate embedding
    embedding = embedder.embeddings(face_image)[0]
    return embedding

def register_user(name, email, password, embedding, payment_methods):
    """Register a new user in the database."""
    try:
        # Hash the password
        hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        with connect_db_with_retry() as conn:
            c = conn.cursor()
            # Insert into user_info
            c.execute("INSERT INTO user_info (name, email, password) VALUES (?, ?, ?)", 
                      (name, email, hashed_pw))
            user_id = c.lastrowid

            # Serialize embedding
            embedding_serialized = pickle.dumps(embedding)

            # Insert into face_embeddings
            c.execute("INSERT INTO face_embeddings (user_id, encoding) VALUES (?, ?)", 
                      (user_id, embedding_serialized))

            # Insert into payment_methods
            for method in payment_methods:
                c.execute("""INSERT INTO payment_methods 
                             (user_id, card_number, bank_name, card_type, expiry_date) 
                             VALUES (?, ?, ?, ?, ?)""", 
                          (user_id, method['card_number'], method['bank_name'], 
                           method['card_type'], method['expiry_date']))
            
            conn.commit()
        
        print(f"User '{name}' registered successfully with ID: {user_id}")
        return user_id

    except Exception as e:
        print(f"Error registering user: {e}")
        return None

def load_user_by_email(email):
    """Load a user's information from the database by email."""
    try:
        with connect_db_with_retry() as conn:
            c = conn.cursor()
            c.execute("SELECT id, name, email, password FROM user_info WHERE email = ?", (email,))
            user = c.fetchone()
        return user
    except Exception as e:
        print(f"Error loading user by email: {e}")
        return None

def verify_face(user_id, captured_image):
    """Verify the captured face against the stored embedding."""
    try:
        with connect_db_with_retry() as conn:
            c = conn.cursor()
            # Retrieve stored face embedding for the given user ID
            c.execute("SELECT encoding FROM face_embeddings WHERE user_id = ?", (user_id,))
            result = c.fetchone()
            if not result:
                print("No face embedding found for user.")
                return False
            
            # Deserialize the stored embedding
            stored_embedding = pickle.loads(result[0])

        # Preprocess and create an embedding for the captured image
        detected_faces = detect_img(captured_image)
        if not detected_faces:
            print("No face detected in captured image.")
            return False

        face_box = detected_faces[0]['box']
        captured_face = ext_face(captured_image, face_box)
        captured_embedding = face_embed(captured_face)

        # Compute cosine similarity between the registered and captured embeddings
        similarity = cosine_similarity(stored_embedding, captured_embedding)
        print(f"Face similarity score: {similarity}")
        print(f"Stored embedding: {stored_embedding[:5]}...")  # Print first 5 values for debugging
        print(f"Captured embedding: {captured_embedding[:5]}...")  # Print first 5 values for debugging

        # Adjust threshold for verification based on testing
        threshold = 0.6  # Lowered threshold
        return similarity >= threshold

    except Exception as e:
        print(f"Error verifying face: {e}")
        return False

def cosine_similarity(a, b):
    """Compute cosine similarity between two vectors."""
    dot_product = np.dot(a, b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0 or norm_b == 0:
        return 0
    return dot_product / (norm_a * norm_b)
