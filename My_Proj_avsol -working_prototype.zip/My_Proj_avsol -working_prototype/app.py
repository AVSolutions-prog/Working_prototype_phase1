from flask import Flask, render_template, request, jsonify, url_for
import bcrypt
import base64
import cv2
import numpy as np
from utils import detect_img, ext_face, face_embed, register_user, load_user_by_email, verify_face
from database import initialize_db, load_payment_methods_by_user_id

app = Flask(__name__)
initialize_db()

def decode_image(image_data):
    """Decode base64 image data to a usable NumPy array (BGR format for OpenCV)."""
    try:
        if ',' in image_data:
            _, base64_data = image_data.split(',', 1)
        else:
            base64_data = image_data
            
        image_bytes = base64.b64decode(base64_data)
        np_arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Decoded image is None. Check base64 encoding.")
        
        return img
    except Exception as e:
        print(f"Error decoding image: {e}")
        return None

@app.route('/')
def index():
    return render_template('welcome.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    try:
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        password = data.get('password')
        face_data = data.get('face_data')
        payment_methods = data.get('payment_methods')

        if not (name and email and password and face_data and payment_methods):
            return jsonify({'status': 'fail', 'message': 'All fields are required'}), 400

        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        faces = detect_img(image)
        if not faces:
            return jsonify({'status': 'fail', 'message': 'No face detected'}), 400
        
        face_image = ext_face(image, faces[0]['box'])
        embedding = face_embed(face_image)

        user_id = register_user(name, email, password, embedding, payment_methods)
        
        if user_id:
            # Return success with a redirect URL
            return jsonify({'status': 'success', 'redirect_url': url_for('registration_success')})
        else:
            return jsonify({'status': 'fail', 'message': 'Registration failed. Please try again.'}), 500

    except Exception as e:
        print(f"Error during registration: {e}")
        return jsonify({'status': 'fail', 'message': 'Registration failed. Please try again.'}), 500

@app.route('/registration_success')
def registration_success():
    return render_template('success.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    try:
        email = request.form.get('email')
        password = request.form.get('password')
        face_data = request.form.get('face_data')

        user = load_user_by_email(email)
        if user is None:
            return jsonify({'status': 'fail', 'message': 'User not found. Please register.'}), 400
        
        user_id, name, _, stored_password = user
        if not bcrypt.checkpw(password.encode('utf-8'), stored_password):
            return jsonify({'status': 'fail', 'message': 'Invalid password'}), 400

        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        if verify_face(user_id, image):
            return jsonify({'status': 'success', 'redirect_url': url_for('products')})
        else:
            return jsonify({'status': 'fail', 'message': 'Face verification failed. Login denied.'}), 400

    except Exception as e:
        print(f"Error during login: {e}")
        return jsonify({'status': 'fail', 'message': 'Login failed. Please try again.'}), 500

@app.route('/products')
def products():
    return render_template('products.html')

@app.route('/checkout', methods=['GET'])
def checkout():
    user_id = 1  # Example user ID, replace with session logic as needed
    payment_methods = load_payment_methods_by_user_id(user_id)
    return render_template('checkout.html', payment_methods=payment_methods, user_id=user_id)

@app.route('/checkout_verification', methods=['POST'])
def checkout_verification():
    try:
        user_id = request.form.get('user_id')
        face_data = request.form.get('face_data')
        payment_method_id = request.form.get('payment_method_id')

        # Decode the face image from base64 to an image
        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        # Verify the captured face with the registered face
        if verify_face(user_id, image):
            # Face matched, proceed with successful checkout
            return jsonify({'status': 'success', 'redirect_url': url_for('payment_success')})
        else:
            # Face verification failed
            return jsonify({'status': 'fail', 'message': 'Face verification failed. Transaction denied.'}), 400

    except Exception as e:
        print(f"Error during face verification at checkout: {e}")
        return jsonify({'status': 'fail', 'message': 'Verification failed. Please try again.'}), 500

@app.route('/payment_success')
def payment_success():
    return render_template('payment_success.html')

if __name__ == "__main__":
    app.run(debug=True)
